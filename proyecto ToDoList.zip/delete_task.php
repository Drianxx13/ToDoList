<?php
include 'Database.php';

$data = json_decode(file_get_contents('php://input'), true);
$taskId = $data['taskId'];

try {
    $stmt = $conn->prepare("DELETE FROM tasks WHERE id = :taskId");
    $stmt->bindParam(':taskId', $taskId);
    $stmt->execute();
    echo "Tarea eliminada correctamente";
} catch (PDOException $e) {
    echo "Error al eliminar la tarea: " . $e->getMessage();
}
?>
