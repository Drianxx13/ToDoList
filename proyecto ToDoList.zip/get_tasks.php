<?php
include 'Database.php';

try {
    $stmt = $conn->prepare("SELECT * FROM tasks");
    $stmt->execute();
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['tasks' => $tasks]);
} catch (PDOException $e) {
    echo "Error al obtener las tareas: " . $e->getMessage();
}
?>
