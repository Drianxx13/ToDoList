let tasks = [];

function addTask() {
  var taskInput = document.getElementById("taskInput");
  var taskText = taskInput.value;
  taskInput.value = "";

  if (taskText.trim() === "") {
    return;
  }

  saveTaskToDatabase(taskText, function (taskIdFromDB) {
    console.log("Tarea guardada con ID: " + taskIdFromDB);

    var listItem = document.createElement("li");
    listItem.textContent = taskText;
    listItem.setAttribute("data-id", taskIdFromDB);

    var deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.classList.add("delete-button");
    deleteButton.addEventListener("click", function () {
      deleteTask(taskIdFromDB);
    });

    listItem.appendChild(deleteButton);

    document.getElementById("todo-list").appendChild(listItem);

    fetch("get_tasks.php")
      .then(response => response.json())
      .then(data => {
        tasks = data.tasks;
        updateTaskList();
      })
      .catch(error => {
        console.error("Error al obtener las tareas: " + error);
      });

  });
  
}

function deleteTask(taskId) {
  const listItem = document.querySelector(`li[data-id="${taskId}"]`);
  console.log("Elemento de tarea a eliminar: ", listItem);

  if (!listItem) {
    console.error(`No se encontró la tarea con el ID ${taskId}`);
    return;
  }

  deleteTaskFromDatabase(taskId, function () {
    listItem.remove();

    fetch("get_tasks.php")
    .then(response => response.json())
    .then(data => {
      tasks = data.tasks;
      updateTaskList();
    })
    .catch(error => {
      console.error("Error al obtener las tareas: " + error);
    });

  });
}

function deleteTaskFromDatabase(taskId, callback) {
  const data = { taskId };
  const requestOptions = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  };

  fetch('delete_task.php', requestOptions)
    .then(response => response.text())
    .then(responseText => {
      console.log(responseText);
      callback();
    })
    .catch(error => {
      console.error('Error al eliminar la tarea: ' + error);
    });
    callback();
}

function updateTaskList() {
  const todoList = document.getElementById('todo-list');

  todoList.innerHTML = '';

  tasks.forEach(task => {
    const li = document.createElement('li');
    li.innerText = task.title;
    li.setAttribute('data-id', task.id);

    if (task.completed) {
      li.classList.add('completed');
    }

    li.addEventListener('click', function () {
      toggleTaskCompletion(task.id);
    });

    const deleteButton = document.createElement('button');
    deleteButton.innerText = 'Delete';
    deleteButton.classList.add('delete-button');
    deleteButton.addEventListener('click', function () {
      deleteTask(task.id);
    });

    li.appendChild(deleteButton);

    todoList.appendChild(li);
  });
}

function saveTaskToDatabase(taskText, callback) {
  fetch("add_task.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ title: taskText })
  })
    .then(response => response.text())
    .then(taskId => {
      callback(taskId);
    })
    .catch(error => {
      console.error("Error al guardar la tarea: " + error);
    });
}

window.addEventListener('load', function () {
  fetch("get_tasks.php")
    .then(response => response.json())
    .then(data => {
      tasks = data.tasks;
      updateTaskList();
    })
    .catch(error => {
      console.error("Error al obtener las tareas: " + error);
    });
});

function handleFormSubmit(event) {
  event.preventDefault();
  addTask();
}

function searchTasks(searchTerm) {
  const filteredTasks = tasks.filter(task => {
    const taskTitle = task.title.toLowerCase();
    return taskTitle.includes(searchTerm.toLowerCase());
  });

  return filteredTasks;
}

function updateSearchResults(searchTerm) {
  const searchResultsContainer = document.getElementById('searchResults');
  searchResultsContainer.innerHTML = '';

  const filteredTasks = searchTasks(searchTerm);

  if (filteredTasks.length === 0) {
    const noResultsMessage = document.createElement('p');
    noResultsMessage.textContent = 'No results found.';
    searchResultsContainer.appendChild(noResultsMessage);
  } else {
    filteredTasks.forEach(task => {
      const taskItem = document.createElement('div');
      taskItem.textContent = task.title;
      taskItem.addEventListener('click', function () {
        scrollToTask(task.id);
      });
      searchResultsContainer.appendChild(taskItem);
    });
  }
}

function scrollToTask(taskId) {
  const taskElement = document.querySelector(`li[data-id="${taskId}"]`);
  if (taskElement) {
    taskElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    taskElement.classList.add('highlight');
    setTimeout(function () {
      taskElement.classList.remove('highlight');
    }, 3000);
  }
}

document.getElementById('searchInput').addEventListener('input', function (event) {
  const searchTerm = event.target.value;
  if (searchTerm.trim() === '') {
    document.getElementById('searchResults').style.display = 'none';
  } else {
    updateSearchResults(searchTerm);
    document.getElementById('searchResults').style.display = 'block';
  }
});
