<?php
include 'Database.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents('php://input'), true);
    $title = $data["title"];

    try {
        $stmt = $conn->prepare("INSERT INTO tasks (title) VALUES (:title)");
        $stmt->bindParam(':title', $title);
        $stmt->execute();

        $taskId = $conn->lastInsertId();
        echo $taskId;
    } catch (PDOException $e) {
        echo "Error al guardar la tarea: " . $e->getMessage();
    }
}
?>
